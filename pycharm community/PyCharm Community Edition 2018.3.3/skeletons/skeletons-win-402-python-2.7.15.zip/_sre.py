# encoding: utf-8
# module _sre
# from (built-in)
# by generator 1.146
# no doc
# no imports

# Variables with simple values

CODESIZE = 4

copyright = ' SRE 2.2.2 Copyright (c) 1997-2002 by Secret Labs AB '

MAGIC = 20031017
MAXREPEAT = 4294967295L

# functions

def compile(*args, **kwargs): # real signature unknown
    pass

def getcodesize(*args, **kwargs): # real signature unknown
    pass

def getlower(*args, **kwargs): # real signature unknown
    pass

# no classes
