# encoding: utf-8
# module _testimportmultiple
# from (pre-generated)
# by generator 1.146
""" _testimportmultiple doc """
# no imports

# no functions
# no classes
# variables with complex values

__loader__ = None # (!) real value is ''

__spec__ = None # (!) real value is ''

